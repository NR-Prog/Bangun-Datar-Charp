﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bangun_Datar
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void tbPanjang_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonHitungSegitiga_Click(object sender, EventArgs e)
        {
            int jari_jari = int.Parse(tbJariJari.Text);

            double keliling_lingkaran = 2 * Math.PI * jari_jari;
            double luas_lingkaran = Math.PI * jari_jari * jari_jari;

            labelKelilingLingkaran.Text = keliling_lingkaran.ToString();
            labelLuasKelilingLingkaran.Text = luas_lingkaran.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}