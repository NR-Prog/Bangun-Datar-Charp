﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bangun_Datar
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonHitungSegitiga_Click(object sender, EventArgs e)
        {
            int sisi1 = int.Parse(tbSisi1.Text);
            int sisi2 = int.Parse(tbSisi2.Text);
            int sisi3 = int.Parse(tbSisi3.Text);
            int alas_segitiga = int.Parse(tbAlasSegitiga.Text);
            int tinggi_segitiga = int.Parse(tbTinggiSegitiga.Text);

            int keliling_segitiga = sisi1 + sisi2 + sisi3;
            double luas_segitiga = 0.5 * alas_segitiga * tinggi_segitiga;

            labelKelilingSegitiga.Text = keliling_segitiga.ToString();
            labelLuasSegitiga.Text = luas_segitiga.ToString();

        }

        private void tbSisi2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}