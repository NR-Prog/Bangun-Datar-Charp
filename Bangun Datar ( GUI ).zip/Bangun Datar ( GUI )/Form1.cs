namespace Bangun_Datar
{
    public partial class Form1 : Form
    {
        Form2 f2;
        Form3 f3;
        Form4 f4;
        public Form1()
        {
            InitializeComponent();
            f2 = new Form2();
            f3 = new Form3();
            f4 = new Form4();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (f2.IsDisposed)
            {
                f2 = new Form2();
                f2.Show();
            }
            else
            {
                f2.Show();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (f3.IsDisposed)
            {
                f3 = new Form3();
                f3.Show();
            }
            else
            {
                f3.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (f4.IsDisposed)
            {
                f4 = new Form4();
                f4.Show();
            }
            else
            {
                f4.Show();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}