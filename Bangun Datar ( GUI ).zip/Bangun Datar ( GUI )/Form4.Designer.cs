﻿namespace Bangun_Datar
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            tbJariJari = new TextBox();
            label1 = new Label();
            groupBox2 = new GroupBox();
            button1 = new Button();
            buttonHitungSegitiga = new Button();
            labelLuasKelilingLingkaran = new Label();
            labelKelilingLingkaran = new Label();
            label5 = new Label();
            label4 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(tbJariJari);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Arial Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(124, 65);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(882, 136);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Diketahui";
            // 
            // tbJariJari
            // 
            tbJariJari.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbJariJari.Location = new Point(294, 63);
            tbJariJari.Name = "tbJariJari";
            tbJariJari.Size = new Size(125, 34);
            tbJariJari.TabIndex = 3;
            tbJariJari.TextChanged += tbPanjang_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(80, 70);
            label1.Name = "label1";
            label1.Size = new Size(188, 27);
            label1.TabIndex = 0;
            label1.Text = "Masukkan Jari-Jari: ";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(buttonHitungSegitiga);
            groupBox2.Controls.Add(labelLuasKelilingLingkaran);
            groupBox2.Controls.Add(labelKelilingLingkaran);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Font = new Font("Arial Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(124, 241);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(882, 248);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            groupBox2.Text = "Hasil";
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(80, 164);
            button1.Name = "button1";
            button1.Size = new Size(297, 43);
            button1.TabIndex = 11;
            button1.Text = "Kembali Menu Utama";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // buttonHitungSegitiga
            // 
            buttonHitungSegitiga.Cursor = Cursors.Hand;
            buttonHitungSegitiga.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonHitungSegitiga.Location = new Point(596, 43);
            buttonHitungSegitiga.Name = "buttonHitungSegitiga";
            buttonHitungSegitiga.Size = new Size(109, 43);
            buttonHitungSegitiga.TabIndex = 9;
            buttonHitungSegitiga.Text = "Hitung";
            buttonHitungSegitiga.UseVisualStyleBackColor = true;
            buttonHitungSegitiga.Click += buttonHitungSegitiga_Click;
            // 
            // labelLuasKelilingLingkaran
            // 
            labelLuasKelilingLingkaran.AutoSize = true;
            labelLuasKelilingLingkaran.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelLuasKelilingLingkaran.Location = new Point(294, 110);
            labelLuasKelilingLingkaran.Name = "labelLuasKelilingLingkaran";
            labelLuasKelilingLingkaran.Size = new Size(0, 27);
            labelLuasKelilingLingkaran.TabIndex = 8;
            // 
            // labelKelilingLingkaran
            // 
            labelKelilingLingkaran.AutoSize = true;
            labelKelilingLingkaran.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelKelilingLingkaran.Location = new Point(294, 52);
            labelKelilingLingkaran.Name = "labelKelilingLingkaran";
            labelKelilingLingkaran.Size = new Size(0, 27);
            labelKelilingLingkaran.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(80, 110);
            label5.Name = "label5";
            label5.Size = new Size(167, 27);
            label5.TabIndex = 7;
            label5.Text = "Luas Lingkaran:  ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(80, 59);
            label4.Name = "label4";
            label4.Size = new Size(191, 27);
            label4.TabIndex = 6;
            label4.Text = "Keliling Lingkaran:  ";
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Gambar_WhatsApp_2025_02_20_pukul_10_31_45_00f86448;
            ClientSize = new Size(1117, 588);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form4";
            Text = "Operasi Lingkaran";
            Load += Form4_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox tbJariJari;
        private Label label1;
        private GroupBox groupBox2;
        private Button buttonHitungSegitiga;
        private Label labelLuasKelilingLingkaran;
        private Label labelKelilingLingkaran;
        private Label label5;
        private Label label4;
        private Button button1;
    }
}