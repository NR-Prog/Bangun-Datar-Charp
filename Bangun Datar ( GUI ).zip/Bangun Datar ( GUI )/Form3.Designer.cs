﻿namespace Bangun_Datar
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            tbLebar = new TextBox();
            tbPanjang = new TextBox();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            button1 = new Button();
            buttonHitungSegitiga = new Button();
            labelLuasPersegiPanjang = new Label();
            labelKelilingPersegiPanjang = new Label();
            label5 = new Label();
            label4 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(tbLebar);
            groupBox1.Controls.Add(tbPanjang);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Arial Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(107, 49);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(882, 189);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Diketahui";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // tbLebar
            // 
            tbLebar.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbLebar.Location = new Point(252, 120);
            tbLebar.Name = "tbLebar";
            tbLebar.Size = new Size(125, 34);
            tbLebar.TabIndex = 4;
            // 
            // tbPanjang
            // 
            tbPanjang.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbPanjang.Location = new Point(252, 63);
            tbPanjang.Name = "tbPanjang";
            tbPanjang.Size = new Size(125, 34);
            tbPanjang.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(80, 128);
            label2.Name = "label2";
            label2.Size = new Size(169, 27);
            label2.TabIndex = 1;
            label2.Text = "Masukkan Lebar: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(80, 70);
            label1.Name = "label1";
            label1.Size = new Size(176, 27);
            label1.TabIndex = 0;
            label1.Text = "Masukkan Tinggi: ";
            label1.Click += label1_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(buttonHitungSegitiga);
            groupBox2.Controls.Add(labelLuasPersegiPanjang);
            groupBox2.Controls.Add(labelKelilingPersegiPanjang);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Font = new Font("Arial Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(107, 282);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(882, 248);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Text = "Hasil";
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(80, 163);
            button1.Name = "button1";
            button1.Size = new Size(297, 43);
            button1.TabIndex = 11;
            button1.Text = "Kembali Menu Utama";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // buttonHitungSegitiga
            // 
            buttonHitungSegitiga.Cursor = Cursors.Hand;
            buttonHitungSegitiga.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonHitungSegitiga.Location = new Point(596, 43);
            buttonHitungSegitiga.Name = "buttonHitungSegitiga";
            buttonHitungSegitiga.Size = new Size(109, 43);
            buttonHitungSegitiga.TabIndex = 9;
            buttonHitungSegitiga.Text = "Hitung";
            buttonHitungSegitiga.UseVisualStyleBackColor = true;
            buttonHitungSegitiga.Click += buttonHitungSegitiga_Click;
            // 
            // labelLuasPersegiPanjang
            // 
            labelLuasPersegiPanjang.AutoSize = true;
            labelLuasPersegiPanjang.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelLuasPersegiPanjang.Location = new Point(355, 110);
            labelLuasPersegiPanjang.Name = "labelLuasPersegiPanjang";
            labelLuasPersegiPanjang.Size = new Size(0, 27);
            labelLuasPersegiPanjang.TabIndex = 8;
            // 
            // labelKelilingPersegiPanjang
            // 
            labelKelilingPersegiPanjang.AutoSize = true;
            labelKelilingPersegiPanjang.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelKelilingPersegiPanjang.Location = new Point(355, 52);
            labelKelilingPersegiPanjang.Name = "labelKelilingPersegiPanjang";
            labelKelilingPersegiPanjang.Size = new Size(0, 27);
            labelKelilingPersegiPanjang.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(80, 110);
            label5.Name = "label5";
            label5.Size = new Size(218, 27);
            label5.TabIndex = 7;
            label5.Text = "Luas Persegi Panjang: ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(80, 59);
            label4.Name = "label4";
            label4.Size = new Size(242, 27);
            label4.TabIndex = 6;
            label4.Text = "Keliling Persegi Panjang: ";
            label4.Click += label4_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Gambar_WhatsApp_2025_02_20_pukul_10_31_45_00f86448;
            ClientSize = new Size(1117, 588);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form3";
            Text = "Operasi Persegi Panjang";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox tbLebar;
        private TextBox tbPanjang;
        private Label label2;
        private Label label1;
        private GroupBox groupBox2;
        private Button buttonHitungSegitiga;
        private Label labelLuasPersegiPanjang;
        private Label labelKelilingPersegiPanjang;
        private Label label5;
        private Label label4;
        private Button button1;
    }
}