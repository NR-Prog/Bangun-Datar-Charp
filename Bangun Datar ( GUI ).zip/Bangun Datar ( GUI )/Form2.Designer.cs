﻿namespace Bangun_Datar
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            tbTinggiSegitiga = new TextBox();
            tbAlasSegitiga = new TextBox();
            label7 = new Label();
            label6 = new Label();
            tbSisi3 = new TextBox();
            tbSisi2 = new TextBox();
            tbSisi1 = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            button1 = new Button();
            buttonHitungSegitiga = new Button();
            labelLuasSegitiga = new Label();
            labelKelilingSegitiga = new Label();
            label5 = new Label();
            label4 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(tbTinggiSegitiga);
            groupBox1.Controls.Add(tbAlasSegitiga);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(tbSisi3);
            groupBox1.Controls.Add(tbSisi2);
            groupBox1.Controls.Add(tbSisi1);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Arial Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(108, 26);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(882, 243);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Diketahui";
            // 
            // tbTinggiSegitiga
            // 
            tbTinggiSegitiga.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbTinggiSegitiga.Location = new Point(644, 116);
            tbTinggiSegitiga.Name = "tbTinggiSegitiga";
            tbTinggiSegitiga.Size = new Size(125, 34);
            tbTinggiSegitiga.TabIndex = 9;
            // 
            // tbAlasSegitiga
            // 
            tbAlasSegitiga.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbAlasSegitiga.Location = new Point(644, 58);
            tbAlasSegitiga.Name = "tbAlasSegitiga";
            tbAlasSegitiga.Size = new Size(125, 34);
            tbAlasSegitiga.TabIndex = 8;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(469, 128);
            label7.Name = "label7";
            label7.Size = new Size(176, 27);
            label7.TabIndex = 7;
            label7.Text = "Masukkan Tinggi: ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(469, 70);
            label6.Name = "label6";
            label6.Size = new Size(157, 27);
            label6.TabIndex = 6;
            label6.Text = "Masukkan Alas: ";
            // 
            // tbSisi3
            // 
            tbSisi3.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbSisi3.Location = new Point(252, 172);
            tbSisi3.Name = "tbSisi3";
            tbSisi3.Size = new Size(125, 34);
            tbSisi3.TabIndex = 5;
            tbSisi3.TextChanged += textBox3_TextChanged;
            // 
            // tbSisi2
            // 
            tbSisi2.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbSisi2.Location = new Point(252, 120);
            tbSisi2.Name = "tbSisi2";
            tbSisi2.Size = new Size(125, 34);
            tbSisi2.TabIndex = 4;
            // 
            // tbSisi1
            // 
            tbSisi1.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbSisi1.HideSelection = false;
            tbSisi1.Location = new Point(252, 63);
            tbSisi1.Name = "tbSisi1";
            tbSisi1.Size = new Size(125, 34);
            tbSisi1.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(80, 179);
            label3.Name = "label3";
            label3.Size = new Size(166, 27);
            label3.TabIndex = 2;
            label3.Text = "Masukkan Sisi 3: ";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(80, 128);
            label2.Name = "label2";
            label2.Size = new Size(166, 27);
            label2.TabIndex = 1;
            label2.Text = "Masukkan Sisi 2: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(80, 70);
            label1.Name = "label1";
            label1.Size = new Size(166, 27);
            label1.TabIndex = 0;
            label1.Text = "Masukkan Sisi 1: ";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(buttonHitungSegitiga);
            groupBox2.Controls.Add(labelLuasSegitiga);
            groupBox2.Controls.Add(labelKelilingSegitiga);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Font = new Font("Arial Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(108, 316);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(882, 248);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Hasil";
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(80, 170);
            button1.Name = "button1";
            button1.Size = new Size(297, 43);
            button1.TabIndex = 10;
            button1.Text = "Kembali Menu Utama";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // buttonHitungSegitiga
            // 
            buttonHitungSegitiga.Cursor = Cursors.Hand;
            buttonHitungSegitiga.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonHitungSegitiga.Location = new Point(596, 43);
            buttonHitungSegitiga.Name = "buttonHitungSegitiga";
            buttonHitungSegitiga.Size = new Size(109, 43);
            buttonHitungSegitiga.TabIndex = 9;
            buttonHitungSegitiga.Text = "Hitung";
            buttonHitungSegitiga.UseVisualStyleBackColor = true;
            buttonHitungSegitiga.Click += buttonHitungSegitiga_Click;
            // 
            // labelLuasSegitiga
            // 
            labelLuasSegitiga.AutoSize = true;
            labelLuasSegitiga.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelLuasSegitiga.Location = new Point(288, 110);
            labelLuasSegitiga.Name = "labelLuasSegitiga";
            labelLuasSegitiga.Size = new Size(0, 27);
            labelLuasSegitiga.TabIndex = 8;
            // 
            // labelKelilingSegitiga
            // 
            labelKelilingSegitiga.AutoSize = true;
            labelKelilingSegitiga.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelKelilingSegitiga.Location = new Point(288, 52);
            labelKelilingSegitiga.Name = "labelKelilingSegitiga";
            labelKelilingSegitiga.Size = new Size(0, 27);
            labelKelilingSegitiga.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(80, 110);
            label5.Name = "label5";
            label5.Size = new Size(140, 27);
            label5.TabIndex = 7;
            label5.Text = "Luas Segitiga:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(80, 52);
            label4.Name = "label4";
            label4.Size = new Size(169, 27);
            label4.TabIndex = 6;
            label4.Text = "Keliling Segitiga: ";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Gambar_WhatsApp_2025_02_20_pukul_10_31_45_00f86448;
            ClientSize = new Size(1117, 588);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form2";
            Text = "Operasi Segitiga";
            Load += Form2_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox tbSisi2;
        private TextBox tbSisi1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox tbSisi3;
        private GroupBox groupBox2;
        private Label labelLuasSegitiga;
        private Label labelKelilingSegitiga;
        private Label label5;
        private Label label4;
        private Button buttonHitungSegitiga;
        private Label label7;
        private Label label6;
        private TextBox tbTinggiSegitiga;
        private TextBox tbAlasSegitiga;
        private Button button1;
    }
}