﻿namespace Bangun_Datar
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            groupBox1 = new GroupBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            groupBox2 = new GroupBox();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(139, 170);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(839, 369);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Daftar Bangun Datar";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(631, 257);
            label5.Name = "label5";
            label5.Size = new Size(137, 32);
            label5.TabIndex = 5;
            label5.Text = "Lingkaran";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(314, 257);
            label4.Name = "label4";
            label4.Size = new Size(217, 32);
            label4.TabIndex = 4;
            label4.Text = "Persegi Panjang";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 257);
            label3.Name = "label3";
            label3.Size = new Size(118, 32);
            label3.TabIndex = 3;
            label3.Text = "Segitiga";
            // 
            // button3
            // 
            button3.BackgroundImage = (Image)resources.GetObject("button3.BackgroundImage");
            button3.BackgroundImageLayout = ImageLayout.Zoom;
            button3.Cursor = Cursors.Hand;
            button3.Location = new Point(640, 122);
            button3.Name = "button3";
            button3.Size = new Size(118, 109);
            button3.TabIndex = 2;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = ImageLayout.Zoom;
            button2.Cursor = Cursors.Hand;
            button2.Location = new Point(357, 122);
            button2.Name = "button2";
            button2.Size = new Size(121, 109);
            button2.TabIndex = 1;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Zoom;
            button1.Cursor = Cursors.Hand;
            button1.Location = new Point(58, 122);
            button1.Name = "button1";
            button1.Size = new Size(118, 109);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(139, 26);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(839, 138);
            groupBox2.TabIndex = 4;
            groupBox2.TabStop = false;
            groupBox2.Enter += groupBox2_Enter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(280, 71);
            label2.Name = "label2";
            label2.Size = new Size(292, 32);
            label2.TabIndex = 7;
            label2.Text = "Aplikasi Bangun Datar";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(314, 23);
            label1.Name = "label1";
            label1.Size = new Size(221, 32);
            label1.TabIndex = 6;
            label1.Text = "Selamat Datang!";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = Properties.Resources.Gambar_WhatsApp_2025_02_20_pukul_10_31_45_00f86448;
            ClientSize = new Size(1117, 588);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Aplikasi Bangun Datar";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private GroupBox groupBox1;
        private Button button1;
        private Button button3;
        private Button button2;
        private Label label5;
        private Label label4;
        private Label label3;
        private GroupBox groupBox2;
        private Label label2;
        private Label label1;
    }
}
