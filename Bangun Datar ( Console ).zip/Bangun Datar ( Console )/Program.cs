﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        
        while (true)
        {
            Console.Clear();
            int bangun_datar;
            Console.WriteLine(" === Aplikasi Bangun Datar === ");
            Console.WriteLine(" 1. Segitiga ");
            Console.WriteLine(" 2. Persegi Panjang ");
            Console.WriteLine(" 3. Lingkaran ");
            Console.Write(" Pilih opsi bangun datar: ");
            bangun_datar = int.Parse(Console.ReadLine());

            switch (bangun_datar)
            {
                case 1:
                    Console.Write("Masukkan Sisi 1: ");
                    int sisi1 = int.Parse(Console.ReadLine());
                    Console.Write("Masukkan Sisi 2: ");
                    int sisi2 = int.Parse(Console.ReadLine());
                    Console.Write("Masukkan Sisi 3: ");
                    int sisi3 = int.Parse(Console.ReadLine());
                    Console.Write("Masukkan Alas: ");
                    int alas = int.Parse(Console.ReadLine());
                    Console.Write("Masukkan Tinggi: ");
                    int tinggi = int.Parse(Console.ReadLine());

                    int keliling_segitiga = sisi1 + sisi2 + sisi3;
                    double luas_segitiga = 0.5 * alas * tinggi;

                    Console.WriteLine($"Keliling Segitiga: {keliling_segitiga}");
                    Console.WriteLine($"Luas Segitiga: {luas_segitiga}");
                    break;

                case 2:
                    Console.Write("Masukkan Panjang: ");
                    int panjang = int.Parse(Console.ReadLine());
                    Console.Write("Masukkan Lebar: ");
                    int lebar = int.Parse(Console.ReadLine());

                    int keliling_persegi_panjang = 2 * (panjang + lebar);
                    double luas_persegi_panjang = panjang * lebar;

                    Console.WriteLine($"Keliling Persegi Panjang: {keliling_persegi_panjang}");
                    Console.WriteLine($"Luas Persegi Panjang: {luas_persegi_panjang}");
                    break;

                case 3:
                    Console.Write("Masukkan Jari-jari: ");
                    float jari_jari = float.Parse(Console.ReadLine());

                    double keliling_lingkaran = 2 * Math.PI * jari_jari;
                    double luas_lingkaran = Math.PI * jari_jari * jari_jari;

                    Console.WriteLine($"Keliling Persegi Panjang: {keliling_lingkaran}");
                    Console.WriteLine($"Luas Persegi Panjang: {luas_lingkaran}");
                    break;

                default:
                    Console.WriteLine("Pilihan tidak tersedia");
                    break;
            }

            Console.Write("Coba Lagi (Y/N)? ");
            string ulang = Console.ReadLine().ToLower();

            if(ulang != "y")
            {
                break;
            }
        }
    }
}